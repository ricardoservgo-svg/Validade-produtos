
let produtos = JSON.parse(localStorage.getItem("produtos")) || [];

function salvarProduto(){

if(produtos.length >= 500){
alert("Limite máximo de 500 produtos atingido");
return;
}

let produto = {
nome: document.getElementById("nome").value,
lote: document.getElementById("lote").value,
quantidade: document.getElementById("quantidade").value,
validade: document.getElementById("validade").value
};

produtos.push(produto);

localStorage.setItem("produtos", JSON.stringify(produtos));

alert("Produto cadastrado com sucesso");

listar();

}

function listar(){

let tabela = document.getElementById("tabelaProdutos");

if(!tabela) return;

tabela.innerHTML="";

let hoje = new Date();

produtos.forEach((p,i)=>{

let data = new Date(p.validade);

let status = "OK";

if(data < hoje) status="VENCIDO";

else if((data-hoje)/86400000 < 7) status="VENCENDO";

tabela.innerHTML += `
<tr>
<td>${p.nome}</td>
<td>${p.lote}</td>
<td>${p.quantidade}</td>
<td>${p.validade}</td>
<td>${status}</td>
<td><button onclick="remover(${i})">Excluir</button></td>
</tr>
`;

});

}

function remover(i){

produtos.splice(i,1);

localStorage.setItem("produtos", JSON.stringify(produtos));

listar();

}

function mostrarCadastro(){

document.getElementById("cadastro").style.display="block";
document.getElementById("lista").style.display="none";
document.getElementById("relatorio").style.display="none";

}

function mostrarLista(){

listar();

document.getElementById("cadastro").style.display="none";
document.getElementById("lista").style.display="block";
document.getElementById("relatorio").style.display="none";

}

function mostrarRelatorio(){

let hoje = new Date();

let vencidos = 0;
let vencendo = 0;

produtos.forEach(p=>{

let data = new Date(p.validade);

if(data < hoje) vencidos++;

else if((data-hoje)/86400000 < 7) vencendo++;

});

document.getElementById("total").innerText="Total de produtos: "+produtos.length;
document.getElementById("vencidos").innerText="Produtos vencidos: "+vencidos;
document.getElementById("vencendo").innerText="Vencendo em até 7 dias: "+vencendo;

document.getElementById("cadastro").style.display="none";
document.getElementById("lista").style.display="none";
document.getElementById("relatorio").style.display="block";

}

listar();
